#include <iostream>
#include "UtilidadesSYS.h"
#include "Coordenada.h"
#include "JuegoPM.h"
#include "Matriz.h"

using namespace std;

int main() {
	chcp1252();
	mainJuegoPM();
	return 0;
}
//Realizado por Miguel Mateos Matias y Carlos Moreno Perez, GRUPO B